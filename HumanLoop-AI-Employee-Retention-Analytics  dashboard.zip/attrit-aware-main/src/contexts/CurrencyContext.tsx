import { createContext, useContext, useState, ReactNode } from 'react';

export type CurrencyCode = 'USD' | 'INR' | 'EUR' | 'GBP' | 'AUD' | 'CAD' | 'JPY' | 'SGD' | 'CHF' | 'AED';

interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  rate: number; // Conversion rate from USD
  locale: string;
  name: string;
}

const CURRENCIES: Record<CurrencyCode, CurrencyConfig> = {
  USD: { code: 'USD', symbol: '$', rate: 1, locale: 'en-US', name: 'US Dollar' },
  INR: { code: 'INR', symbol: '₹', rate: 83.5, locale: 'en-IN', name: 'Indian Rupee' },
  EUR: { code: 'EUR', symbol: '€', rate: 0.92, locale: 'de-DE', name: 'Euro' },
  GBP: { code: 'GBP', symbol: '£', rate: 0.79, locale: 'en-GB', name: 'British Pound' },
  AUD: { code: 'AUD', symbol: 'A$', rate: 1.53, locale: 'en-AU', name: 'Australian Dollar' },
  CAD: { code: 'CAD', symbol: 'C$', rate: 1.36, locale: 'en-CA', name: 'Canadian Dollar' },
  JPY: { code: 'JPY', symbol: '¥', rate: 149.5, locale: 'ja-JP', name: 'Japanese Yen' },
  SGD: { code: 'SGD', symbol: 'S$', rate: 1.34, locale: 'en-SG', name: 'Singapore Dollar' },
  CHF: { code: 'CHF', symbol: 'Fr', rate: 0.88, locale: 'de-CH', name: 'Swiss Franc' },
  AED: { code: 'AED', symbol: 'د.إ', rate: 3.67, locale: 'ar-AE', name: 'UAE Dirham' },
};

interface CurrencyContextType {
  currency: CurrencyCode;
  setCurrency: (currency: CurrencyCode) => void;
  config: CurrencyConfig;
  formatCurrency: (amountUSD: number, compact?: boolean) => string;
  convertAmount: (amountUSD: number) => number;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: ReactNode }) {
  const [currency, setCurrency] = useState<CurrencyCode>('USD');
  const config = CURRENCIES[currency];

  const convertAmount = (amountUSD: number): number => {
    return amountUSD * config.rate;
  };

  const formatCurrency = (amountUSD: number, compact = false): string => {
    const converted = convertAmount(amountUSD);
    
    if (compact) {
      if (Math.abs(converted) >= 1000000) {
        return `${config.symbol}${(converted / 1000000).toFixed(1)}M`;
      } else if (Math.abs(converted) >= 1000) {
        return `${config.symbol}${(converted / 1000).toFixed(0)}K`;
      }
    }
    
    return new Intl.NumberFormat(config.locale, {
      style: 'currency',
      currency: config.code,
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(converted);
  };

  return (
    <CurrencyContext.Provider value={{ currency, setCurrency, config, formatCurrency, convertAmount }}>
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
}

export { CURRENCIES };
