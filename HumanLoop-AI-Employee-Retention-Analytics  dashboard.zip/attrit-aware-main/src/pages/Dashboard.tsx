import { useState, useMemo, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Users,
  TrendingDown,
  AlertTriangle,
  DollarSign,
  PiggyBank,
  Brain,
  Target,
  Shield,
  Layers,
  LineChart,
  Lightbulb,
} from 'lucide-react';

import { KPICard } from '@/components/dashboard/KPICard';
import { RiskGauge } from '@/components/dashboard/RiskGauge';
import { EmployeeTable } from '@/components/dashboard/EmployeeTable';
import { FeatureImportanceChart } from '@/components/dashboard/FeatureImportanceChart';
import { DepartmentChart } from '@/components/dashboard/DepartmentChart';
import { ModelComparisonChart } from '@/components/dashboard/ModelComparisonChart';
import { PolicySimulator } from '@/components/dashboard/PolicySimulator';
import { RiskDistributionChart } from '@/components/dashboard/RiskDistributionChart';
import { SurvivalChart } from '@/components/dashboard/SurvivalChart';
import { ClusterView } from '@/components/dashboard/ClusterView';
import { BiasAnalysis } from '@/components/dashboard/BiasAnalysis';
import { RecommendationsPanel } from '@/components/dashboard/RecommendationsPanel';
import { FilterBar } from '@/components/dashboard/FilterBar';
import { DecisionContext } from '@/components/dashboard/DecisionContext';
import { HumanLoopConfirmation } from '@/components/dashboard/HumanLoopConfirmation';
import { ModelInfo } from '@/components/dashboard/ModelInfo';
import { Disclaimer } from '@/components/dashboard/Disclaimer';
import { RiskLegend } from '@/components/dashboard/RiskBadge';
import { CurrencySelector } from '@/components/dashboard/CurrencySelector';
import { CurrencyProvider, useCurrency } from '@/contexts/CurrencyContext';

import {
  Employee,
  parseCSVData,
  generateDepartmentData,
  generateRiskDistribution,
} from '@/lib/employeeData';

import csvData from '@/data/employee-attrition.csv?raw';

function DashboardContent() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | undefined>();
  const [selectedDepartment, setSelectedDepartment] = useState('');
  const [selectedRole, setSelectedRole] = useState('');
  const [selectedGender, setSelectedGender] = useState('');
  const [selectedRisk, setSelectedRisk] = useState('');
  const { formatCurrency } = useCurrency();

  useEffect(() => {
    const parsed = parseCSVData(csvData);
    setEmployees(parsed);
  }, []);

  const filteredEmployees = useMemo(() => {
    return employees.filter((emp) => {
      if (selectedDepartment && selectedDepartment !== 'all' && emp.department !== selectedDepartment) return false;
      if (selectedRole && selectedRole !== 'all' && emp.jobRole !== selectedRole) return false;
      if (selectedGender && selectedGender !== 'all' && emp.gender !== selectedGender) return false;
      if (selectedRisk && selectedRisk !== 'all' && emp.riskLevel !== selectedRisk) return false;
      return true;
    });
  }, [employees, selectedDepartment, selectedRole, selectedGender, selectedRisk]);

  const kpis = useMemo(() => {
    const total = filteredEmployees.length;
    const attritionCount = filteredEmployees.filter((e) => e.attrition).length;
    const highRiskCount = filteredEmployees.filter((e) => e.riskLevel === 'High' || e.riskLevel === 'Critical').length;
    const avgRisk = filteredEmployees.reduce((sum, e) => sum + e.riskScore, 0) / (total || 1);
    const attritionCost = filteredEmployees.filter((e) => e.attrition).reduce((sum, e) => sum + e.attritionCost, 0);
    const potentialSavings = filteredEmployees
      .filter((e) => e.riskLevel === 'High' || e.riskLevel === 'Critical')
      .reduce((sum, e) => sum + e.attritionCost * 0.4, 0);

    return {
      total,
      attritionRate: total ? (attritionCount / total) * 100 : 0,
      highRiskCount,
      avgRisk,
      attritionCost,
      potentialSavings,
    };
  }, [filteredEmployees]);

  const departments = useMemo(() => [...new Set(employees.map((e) => e.department))], [employees]);
  const roles = useMemo(() => [...new Set(employees.map((e) => e.jobRole))], [employees]);
  const departmentData = useMemo(() => generateDepartmentData(filteredEmployees), [filteredEmployees]);
  const riskDistribution = useMemo(() => generateRiskDistribution(filteredEmployees), [filteredEmployees]);

  const clearFilters = () => {
    setSelectedDepartment('');
    setSelectedRole('');
    setSelectedGender('');
    setSelectedRisk('');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 sm:px-6 py-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h1 className="text-xl sm:text-2xl font-bold text-foreground">
                HumanLoop AI — Employee Retention Analytics
              </h1>
              <p className="text-xs sm:text-sm text-muted-foreground mt-1">
                Decision Support System for Strategic HR Management
              </p>
            </div>
            <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
              <ModelInfo />
              <CurrencySelector />
              <Badge variant="outline" className="bg-success/10 text-success border-success/30 text-xs">
                <span className="w-1.5 h-1.5 bg-success rounded-full mr-1.5 animate-pulse" />
                Live
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 sm:px-6 py-6 space-y-6">
        {/* Filters */}
        <FilterBar
          departments={departments}
          roles={roles}
          selectedDepartment={selectedDepartment}
          selectedRole={selectedRole}
          selectedGender={selectedGender}
          selectedRisk={selectedRisk}
          onDepartmentChange={setSelectedDepartment}
          onRoleChange={setSelectedRole}
          onGenderChange={setSelectedGender}
          onRiskChange={setSelectedRisk}
          onClearFilters={clearFilters}
        />

        {/* Risk Legend */}
        <RiskLegend className="py-2" />

        {/* Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-secondary/50 border border-border/50 p-1 h-auto flex flex-wrap gap-1">
            <TabsTrigger value="overview" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Target className="h-3.5 w-3.5 mr-1.5" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="analysis" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <LineChart className="h-3.5 w-3.5 mr-1.5" />
              Risk Analysis
            </TabsTrigger>
            <TabsTrigger value="models" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Brain className="h-3.5 w-3.5 mr-1.5" />
              ML Models
            </TabsTrigger>
            <TabsTrigger value="explainability" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Lightbulb className="h-3.5 w-3.5 mr-1.5" />
              Explainable AI
            </TabsTrigger>
            <TabsTrigger value="simulator" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Layers className="h-3.5 w-3.5 mr-1.5" />
              Policy Simulator
            </TabsTrigger>
            <TabsTrigger value="governance" className="text-xs data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              <Shield className="h-3.5 w-3.5 mr-1.5" />
              AI Governance
            </TabsTrigger>
          </TabsList>

          {/* OVERVIEW TAB */}
          <TabsContent value="overview" className="space-y-6 animate-fade-in">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
              <KPICard
                title="Total Employees"
                value={kpis.total.toLocaleString()}
                subtitle="Active workforce"
                icon={<Users className="h-4 w-4" />}
                variant="primary"
                tooltip="Total number of employees in the filtered dataset"
              />
              <KPICard
                title="Attrition Rate"
                value={`${kpis.attritionRate.toFixed(1)}%`}
                subtitle="Historical turnover"
                trend="down"
                trendValue="2.3%"
                icon={<TrendingDown className="h-4 w-4" />}
                variant="success"
                tooltip="Percentage of employees who have left the company"
              />
              <KPICard
                title="High-Risk"
                value={kpis.highRiskCount}
                subtitle={`${((kpis.highRiskCount / kpis.total) * 100).toFixed(1)}% of total`}
                icon={<AlertTriangle className="h-4 w-4" />}
                variant="danger"
                tooltip="Employees with risk score ≥50% requiring immediate attention"
              />
              <KPICard
                title="Attrition Cost"
                value={formatCurrency(kpis.attritionCost, true)}
                subtitle="Annual impact"
                icon={<DollarSign className="h-4 w-4" />}
                variant="warning"
                tooltip="Estimated cost of employee turnover"
              />
              <KPICard
                title="Potential Savings"
                value={formatCurrency(kpis.potentialSavings, true)}
                subtitle="Through interventions"
                icon={<PiggyBank className="h-4 w-4" />}
                variant="success"
                tooltip="Estimated savings if high-risk attrition reduced by 40%"
              />
            </div>

            {/* Risk Overview Row */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card className="glass-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Overall Risk Level</CardTitle>
                  <CardDescription className="text-xs">Aggregate attrition risk</CardDescription>
                </CardHeader>
                <CardContent className="flex justify-center pt-2">
                  <RiskGauge value={Math.round(kpis.avgRisk)} size="lg" />
                </CardContent>
                <div className="px-6 pb-4">
                  <DecisionContext
                    insight="Current average risk suggests moderate retention challenges. Focus interventions on high-risk segments."
                  />
                </div>
              </Card>

              <Card className="glass-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Risk Distribution</CardTitle>
                  <CardDescription className="text-xs">Employees by risk category</CardDescription>
                </CardHeader>
                <CardContent>
                  <RiskDistributionChart data={riskDistribution} />
                </CardContent>
                <div className="px-6 pb-4">
                  <DecisionContext
                    insight="High-risk employees should be prioritized for immediate retention conversations."
                    variant="warning"
                  />
                </div>
              </Card>

              <Card className="glass-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Department Analysis</CardTitle>
                  <CardDescription className="text-xs">Attrition rate by department</CardDescription>
                </CardHeader>
                <CardContent>
                  <DepartmentChart data={departmentData} metric="attritionRate" />
                </CardContent>
                <div className="px-6 pb-4">
                  <DecisionContext
                    insight="Sales and R&D departments show elevated attrition. Consider targeted engagement programs."
                  />
                </div>
              </Card>
            </div>

            {/* Employee Table + Recommendations */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              <Card className="glass-card lg:col-span-2">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Employee Risk Overview</CardTitle>
                  <CardDescription className="text-xs">Click on an employee to see recommendations</CardDescription>
                </CardHeader>
                <CardContent>
                  <EmployeeTable
                    employees={filteredEmployees}
                    onSelectEmployee={setSelectedEmployee}
                  />
                </CardContent>
              </Card>

              <Card className="glass-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Retention Recommendations</CardTitle>
                  <CardDescription className="text-xs">AI-powered actionable insights</CardDescription>
                </CardHeader>
                <CardContent>
                  <RecommendationsPanel employee={selectedEmployee} />
                  {selectedEmployee && (
                    <HumanLoopConfirmation className="mt-4" />
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* RISK ANALYSIS TAB */}
          <TabsContent value="analysis" className="space-y-6 animate-fade-in">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="glass-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Retention Survival Curve</CardTitle>
                  <CardDescription className="text-xs">Probability of retention over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <SurvivalChart />
                </CardContent>
                <div className="px-6 pb-4">
                  <DecisionContext
                    insight="First 2 years show highest attrition risk. Onboarding and early engagement are critical."
                    variant="warning"
                  />
                </div>
              </Card>

              <Card className="glass-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Cost by Department</CardTitle>
                  <CardDescription className="text-xs">Historical attrition cost distribution</CardDescription>
                </CardHeader>
                <CardContent>
                  <DepartmentChart data={departmentData} metric="attritionCost" />
                </CardContent>
                <div className="px-6 pb-4">
                  <DecisionContext
                    insight="R&D has highest replacement costs. Technical talent retention should be prioritized."
                  />
                </div>
              </Card>
            </div>

            <Card className="glass-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Employee Segments</CardTitle>
                <CardDescription className="text-xs">Cluster analysis based on behavior patterns</CardDescription>
              </CardHeader>
              <CardContent>
                <ClusterView />
              </CardContent>
            </Card>
          </TabsContent>

          {/* ML MODELS TAB */}
          <TabsContent value="models" className="space-y-6 animate-fade-in">
            <Card className="glass-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Model Performance Comparison</CardTitle>
                <CardDescription className="text-xs">
                  ML & DL models evaluated on AUC, Recall, and Stability
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ModelComparisonChart />
              </CardContent>
              <div className="px-6 pb-4">
                <DecisionContext
                  insight="Ensemble model provides best balance of accuracy and stability. Used for all predictions."
                  variant="success"
                />
              </div>
            </Card>
          </TabsContent>

          {/* EXPLAINABILITY TAB */}
          <TabsContent value="explainability" className="space-y-6 animate-fade-in">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <Card className="glass-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Feature Importance (SHAP)</CardTitle>
                  <CardDescription className="text-xs">
                    Key factors driving attrition predictions
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <FeatureImportanceChart />
                </CardContent>
                <div className="px-6 pb-4">
                  <DecisionContext
                    insight="Employees with high overtime and low salary show significantly higher attrition risk."
                    variant="warning"
                  />
                </div>
              </Card>

              <Card className="glass-card">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium">Counterfactual Insights</CardTitle>
                  <CardDescription className="text-xs">What changes would reduce risk?</CardDescription>
                </CardHeader>
                <CardContent>
                  <RecommendationsPanel employee={selectedEmployee} compact />
                  {!selectedEmployee && (
                    <p className="text-xs text-muted-foreground text-center mt-4">
                      Select an employee from Overview to see analysis
                    </p>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* POLICY SIMULATOR TAB */}
          <TabsContent value="simulator" className="space-y-6 animate-fade-in">
            <Card className="glass-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">HR Policy Simulator</CardTitle>
                <CardDescription className="text-xs">
                  Adjust policy levers to simulate impact on attrition risk and ROI
                </CardDescription>
              </CardHeader>
              <CardContent>
                <PolicySimulator />
              </CardContent>
            </Card>
            <HumanLoopConfirmation />
          </TabsContent>

          {/* GOVERNANCE TAB */}
          <TabsContent value="governance" className="space-y-6 animate-fade-in">
            <Card className="glass-card">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Ethical AI & Bias Analysis</CardTitle>
                <CardDescription className="text-xs">
                  Ensuring fair and transparent predictions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BiasAnalysis />
              </CardContent>
            </Card>
            <HumanLoopConfirmation />
          </TabsContent>
        </Tabs>

        {/* Disclaimer */}
        <Disclaimer />
      </main>

      {/* Footer */}
      <footer className="border-t border-border/50 py-6 bg-card/30">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <p className="text-xs font-medium text-foreground">
                Predictive Analytics for Employee Retention in IT Companies
              </p>
              <p className="text-[10px] text-muted-foreground mt-1">
                Technologies: Data Science, Machine Learning, Deep Learning, Explainable AI
              </p>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="text-[10px]">
                IBM HR Analytics Dataset
              </Badge>
              <Badge variant="outline" className="text-[10px] bg-primary/10 text-primary border-primary/30">
                Ensemble Model v1.0
              </Badge>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default function Dashboard() {
  return (
    <CurrencyProvider>
      <DashboardContent />
    </CurrencyProvider>
  );
}
