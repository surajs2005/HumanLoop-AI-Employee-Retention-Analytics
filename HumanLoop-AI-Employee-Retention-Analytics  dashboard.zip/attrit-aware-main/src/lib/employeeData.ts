// Employee data types and utilities for the HR Analytics Dashboard

export interface Employee {
  id: number;
  age: number;
  attrition: boolean;
  businessTravel: string;
  dailyRate: number;
  department: string;
  distanceFromHome: number;
  education: number;
  educationField: string;
  gender: string;
  hourlyRate: number;
  jobInvolvement: number;
  jobLevel: number;
  jobRole: string;
  jobSatisfaction: number;
  maritalStatus: string;
  monthlyIncome: number;
  monthlyRate: number;
  numCompaniesWorked: number;
  overTime: boolean;
  percentSalaryHike: number;
  performanceRating: number;
  relationshipSatisfaction: number;
  stockOptionLevel: number;
  totalWorkingYears: number;
  trainingTimesLastYear: number;
  workLifeBalance: number;
  yearsAtCompany: number;
  yearsInCurrentRole: number;
  yearsSinceLastPromotion: number;
  yearsWithCurrManager: number;
  // Computed fields
  riskScore: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  attritionCost: number;
}

// Calculate risk score based on key factors
export function calculateRiskScore(emp: Partial<Employee>): number {
  let score = 0;
  
  // Overtime is a strong predictor
  if (emp.overTime) score += 20;
  
  // Low job satisfaction
  if (emp.jobSatisfaction === 1) score += 15;
  else if (emp.jobSatisfaction === 2) score += 8;
  
  // Work-life balance
  if (emp.workLifeBalance === 1) score += 15;
  else if (emp.workLifeBalance === 2) score += 8;
  
  // Years since promotion
  if ((emp.yearsSinceLastPromotion || 0) > 5) score += 12;
  else if ((emp.yearsSinceLastPromotion || 0) > 3) score += 6;
  
  // Low income relative to job level
  const expectedIncome = (emp.jobLevel || 1) * 4000;
  if ((emp.monthlyIncome || 0) < expectedIncome * 0.7) score += 10;
  
  // Environment satisfaction
  if (emp.jobInvolvement === 1) score += 10;
  
  // Distance from home
  if ((emp.distanceFromHome || 0) > 20) score += 8;
  
  // Frequent travel
  if (emp.businessTravel === 'Travel_Frequently') score += 8;
  
  // Young age and low tenure (flight risk)
  if ((emp.age || 30) < 28 && (emp.yearsAtCompany || 0) < 2) score += 10;
  
  // Low stock options
  if (emp.stockOptionLevel === 0) score += 5;
  
  // Normalize to 0-100
  return Math.min(100, Math.max(0, score));
}

export function getRiskLevel(score: number): 'Low' | 'Medium' | 'High' | 'Critical' {
  if (score >= 70) return 'Critical';
  if (score >= 50) return 'High';
  if (score >= 30) return 'Medium';
  return 'Low';
}

export function calculateAttritionCost(emp: Partial<Employee>): number {
  // Typically 0.5-2x annual salary
  const annualSalary = (emp.monthlyIncome || 5000) * 12;
  const multiplier = (emp.jobLevel || 1) >= 3 ? 1.5 : 1.0;
  return Math.round(annualSalary * multiplier);
}

// Parse CSV data
export function parseCSVData(csvText: string): Employee[] {
  const lines = csvText.trim().split('\n');
  const headers = lines[0].replace(/^\uFEFF/, '').split(',');
  
  return lines.slice(1).map((line, index) => {
    const values = line.split(',');
    const emp: Partial<Employee> = {
      id: index + 1,
      age: parseInt(values[0]) || 30,
      attrition: values[1] === 'Yes',
      businessTravel: values[2] || 'Travel_Rarely',
      dailyRate: parseInt(values[3]) || 800,
      department: values[4] || 'Research & Development',
      distanceFromHome: parseInt(values[5]) || 5,
      education: parseInt(values[6]) || 3,
      educationField: values[7] || 'Life Sciences',
      gender: values[11] || 'Male',
      hourlyRate: parseInt(values[12]) || 65,
      jobInvolvement: parseInt(values[13]) || 3,
      jobLevel: parseInt(values[14]) || 2,
      jobRole: values[15] || 'Research Scientist',
      jobSatisfaction: parseInt(values[16]) || 3,
      maritalStatus: values[17] || 'Married',
      monthlyIncome: parseInt(values[18]) || 5000,
      monthlyRate: parseInt(values[19]) || 15000,
      numCompaniesWorked: parseInt(values[20]) || 2,
      overTime: values[22] === 'Yes',
      percentSalaryHike: parseInt(values[23]) || 12,
      performanceRating: parseInt(values[24]) || 3,
      relationshipSatisfaction: parseInt(values[25]) || 3,
      stockOptionLevel: parseInt(values[27]) || 1,
      totalWorkingYears: parseInt(values[28]) || 8,
      trainingTimesLastYear: parseInt(values[29]) || 2,
      workLifeBalance: parseInt(values[30]) || 3,
      yearsAtCompany: parseInt(values[31]) || 5,
      yearsInCurrentRole: parseInt(values[32]) || 3,
      yearsSinceLastPromotion: parseInt(values[33]) || 1,
      yearsWithCurrManager: parseInt(values[34]) || 3,
    };
    
    emp.riskScore = calculateRiskScore(emp);
    emp.riskLevel = getRiskLevel(emp.riskScore);
    emp.attritionCost = calculateAttritionCost(emp);
    
    return emp as Employee;
  });
}

// Sample data for demo
const sampleEmployeesRaw = [
  { id: 1, age: 41, attrition: false, businessTravel: 'Travel_Rarely', dailyRate: 1102, department: 'Sales', distanceFromHome: 1, education: 2, educationField: 'Life Sciences', gender: 'Female', hourlyRate: 94, jobInvolvement: 3, jobLevel: 2, jobRole: 'Sales Executive', jobSatisfaction: 4, maritalStatus: 'Single', monthlyIncome: 5993, monthlyRate: 19479, numCompaniesWorked: 8, overTime: true, percentSalaryHike: 11, performanceRating: 3, relationshipSatisfaction: 1, stockOptionLevel: 0, totalWorkingYears: 8, trainingTimesLastYear: 0, workLifeBalance: 1, yearsAtCompany: 6, yearsInCurrentRole: 4, yearsSinceLastPromotion: 0, yearsWithCurrManager: 5 },
  { id: 2, age: 49, attrition: false, businessTravel: 'Travel_Frequently', dailyRate: 279, department: 'Research & Development', distanceFromHome: 8, education: 1, educationField: 'Life Sciences', gender: 'Male', hourlyRate: 61, jobInvolvement: 2, jobLevel: 2, jobRole: 'Research Scientist', jobSatisfaction: 2, maritalStatus: 'Married', monthlyIncome: 5130, monthlyRate: 24907, numCompaniesWorked: 1, overTime: false, percentSalaryHike: 23, performanceRating: 4, relationshipSatisfaction: 4, stockOptionLevel: 1, totalWorkingYears: 10, trainingTimesLastYear: 3, workLifeBalance: 3, yearsAtCompany: 10, yearsInCurrentRole: 7, yearsSinceLastPromotion: 1, yearsWithCurrManager: 7 },
  { id: 3, age: 37, attrition: true, businessTravel: 'Travel_Rarely', dailyRate: 1373, department: 'Research & Development', distanceFromHome: 2, education: 2, educationField: 'Other', gender: 'Male', hourlyRate: 92, jobInvolvement: 2, jobLevel: 1, jobRole: 'Laboratory Technician', jobSatisfaction: 3, maritalStatus: 'Single', monthlyIncome: 2090, monthlyRate: 2396, numCompaniesWorked: 6, overTime: true, percentSalaryHike: 15, performanceRating: 3, relationshipSatisfaction: 2, stockOptionLevel: 0, totalWorkingYears: 7, trainingTimesLastYear: 3, workLifeBalance: 3, yearsAtCompany: 0, yearsInCurrentRole: 0, yearsSinceLastPromotion: 0, yearsWithCurrManager: 0 },
];

export const sampleEmployees: Employee[] = sampleEmployeesRaw.map(emp => {
  const riskScore = calculateRiskScore(emp);
  return {
    ...emp,
    riskScore,
    riskLevel: getRiskLevel(riskScore),
    attritionCost: calculateAttritionCost(emp),
  };
});

// Generate mock data for charts
export function generateDepartmentData(employees: Employee[]) {
  const depts = ['Sales', 'Research & Development', 'Human Resources'];
  return depts.map(dept => {
    const deptEmps = employees.filter(e => e.department === dept);
    const attritionCount = deptEmps.filter(e => e.attrition).length;
    const avgRisk = deptEmps.reduce((sum, e) => sum + e.riskScore, 0) / (deptEmps.length || 1);
    return {
      department: dept === 'Research & Development' ? 'R&D' : dept,
      fullName: dept,
      employees: deptEmps.length,
      attritionRate: deptEmps.length ? (attritionCount / deptEmps.length * 100) : 0,
      avgRiskScore: avgRisk,
      attritionCost: deptEmps.reduce((sum, e) => sum + (e.attrition ? e.attritionCost : 0), 0),
    };
  });
}

export function generateJobRoleData(employees: Employee[]) {
  const roles = [...new Set(employees.map(e => e.jobRole))];
  return roles.map(role => {
    const roleEmps = employees.filter(e => e.jobRole === role);
    const attritionCount = roleEmps.filter(e => e.attrition).length;
    return {
      role: role.length > 15 ? role.substring(0, 15) + '...' : role,
      fullRole: role,
      employees: roleEmps.length,
      attritionRate: roleEmps.length ? (attritionCount / roleEmps.length * 100) : 0,
      avgRiskScore: roleEmps.reduce((sum, e) => sum + e.riskScore, 0) / (roleEmps.length || 1),
    };
  }).sort((a, b) => b.attritionRate - a.attritionRate).slice(0, 8);
}

export function generateFeatureImportance() {
  return [
    { feature: 'Overtime', importance: 0.28, direction: 'negative' },
    { feature: 'Monthly Income', importance: 0.18, direction: 'positive' },
    { feature: 'Job Satisfaction', importance: 0.15, direction: 'positive' },
    { feature: 'Work-Life Balance', importance: 0.12, direction: 'positive' },
    { feature: 'Years at Company', importance: 0.10, direction: 'positive' },
    { feature: 'Distance from Home', importance: 0.08, direction: 'negative' },
    { feature: 'Environment Satisfaction', importance: 0.05, direction: 'positive' },
    { feature: 'Stock Option Level', importance: 0.04, direction: 'positive' },
  ];
}

export function generateModelComparison() {
  return [
    { model: 'Logistic Regression', auc: 0.79, recall: 0.72, stability: 0.91, type: 'ML' },
    { model: 'Random Forest', auc: 0.84, recall: 0.78, stability: 0.88, type: 'ML' },
    { model: 'XGBoost', auc: 0.86, recall: 0.81, stability: 0.87, type: 'ML' },
    { model: 'Neural Network (MLP)', auc: 0.85, recall: 0.83, stability: 0.82, type: 'DL' },
    { model: 'Ensemble', auc: 0.88, recall: 0.85, stability: 0.90, type: 'Ensemble' },
  ];
}

export function generateRiskDistribution(employees: Employee[]) {
  const levels = ['Low', 'Medium', 'High', 'Critical'] as const;
  return levels.map(level => ({
    level,
    count: employees.filter(e => e.riskLevel === level).length,
    percentage: (employees.filter(e => e.riskLevel === level).length / employees.length * 100),
  }));
}

export function generateSurvivalData() {
  return [
    { month: 0, survival: 100 },
    { month: 6, survival: 94 },
    { month: 12, survival: 88 },
    { month: 18, survival: 83 },
    { month: 24, survival: 78 },
    { month: 30, survival: 74 },
    { month: 36, survival: 71 },
    { month: 42, survival: 68 },
    { month: 48, survival: 66 },
  ];
}

export function generateClusterData() {
  return [
    { cluster: 'High Performers', count: 312, attritionRate: 8.2, avgTenure: 7.5, avgIncome: 8500, description: 'Top performers with high satisfaction' },
    { cluster: 'Career Climbers', count: 245, attritionRate: 18.5, avgTenure: 3.2, avgIncome: 5200, description: 'Ambitious, seeking growth opportunities' },
    { cluster: 'Steady Contributors', count: 428, attritionRate: 12.1, avgTenure: 8.8, avgIncome: 6100, description: 'Reliable, moderate satisfaction' },
    { cluster: 'At-Risk Talent', count: 156, attritionRate: 32.4, avgTenure: 2.1, avgIncome: 3800, description: 'High workload, low satisfaction' },
    { cluster: 'Senior Experts', count: 189, attritionRate: 5.8, avgTenure: 12.3, avgIncome: 12500, description: 'Experienced, high retention' },
  ];
}

export function generateBiasData() {
  return {
    gender: [
      { group: 'Male', predictedRisk: 24.5, actualAttrition: 17.0, count: 882 },
      { group: 'Female', predictedRisk: 26.2, actualAttrition: 14.8, count: 588 },
    ],
    jobLevel: [
      { group: 'Level 1', predictedRisk: 28.1, actualAttrition: 26.3, count: 543 },
      { group: 'Level 2', predictedRisk: 22.4, actualAttrition: 17.8, count: 534 },
      { group: 'Level 3', predictedRisk: 18.2, actualAttrition: 10.4, count: 218 },
      { group: 'Level 4', predictedRisk: 12.5, actualAttrition: 8.2, count: 106 },
      { group: 'Level 5', predictedRisk: 8.8, actualAttrition: 3.2, count: 69 },
    ],
  };
}