import { useState } from 'react';
import { ChevronDown, ChevronUp, AlertTriangle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';

interface DisclaimerProps {
  className?: string;
}

export function Disclaimer({ className }: DisclaimerProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  const limitations = [
    'Based on historical data patterns—may not reflect current conditions',
    'No real-time data updates—predictions are batch-processed',
    'All predictions require human review before action',
    'Model accuracy may vary across employee segments',
    'External factors (market conditions, company changes) not captured',
  ];

  return (
    <div className={cn('border-t border-border/50 pt-4', className)}>
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full justify-between text-muted-foreground hover:text-foreground h-auto py-2"
      >
        <div className="flex items-center gap-2">
          <Info className="h-4 w-4" />
          <span className="text-xs font-medium">Model Limitations & Disclaimer</span>
        </div>
        {isExpanded ? (
          <ChevronUp className="h-4 w-4" />
        ) : (
          <ChevronDown className="h-4 w-4" />
        )}
      </Button>

      {isExpanded && (
        <div className="mt-3 p-4 rounded-lg bg-warning/5 border border-warning/20 animate-fade-in">
          <div className="flex items-start gap-3">
            <AlertTriangle className="h-4 w-4 text-warning shrink-0 mt-0.5" />
            <div className="space-y-2">
              <p className="text-xs font-medium text-foreground">Important Considerations</p>
              <ul className="space-y-1.5">
                {limitations.map((limitation, index) => (
                  <li key={index} className="text-xs text-muted-foreground flex items-start gap-2">
                    <span className="text-warning mt-0.5">•</span>
                    {limitation}
                  </li>
                ))}
              </ul>
              <p className="text-[10px] text-muted-foreground pt-2 border-t border-border/50">
                This system is designed to support HR decision-making, not replace human judgment.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
