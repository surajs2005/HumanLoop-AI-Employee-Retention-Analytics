import { useState, useMemo } from 'react';
import { Slider } from '@/components/ui/slider';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { TrendingDown, DollarSign, Users } from 'lucide-react';
import { useCurrency } from '@/contexts/CurrencyContext';

interface SimulationResult {
  riskReduction: number;
  costSavings: number;
  employeesImpacted: number;
}

export function PolicySimulator() {
  const [salaryHike, setSalaryHike] = useState(0);
  const [promotionRate, setPromotionRate] = useState(0);
  const [workloadReduction, setWorkloadReduction] = useState(0);
  const [trainingHours, setTrainingHours] = useState(0);
  const { formatCurrency } = useCurrency();

  const result = useMemo<SimulationResult>(() => {
    const baseRisk = 16.1;
    
    let reduction = 0;
    reduction += salaryHike * 0.15;
    reduction += promotionRate * 0.25;
    reduction += workloadReduction * 0.2;
    reduction += trainingHours * 0.05;
    
    const newRisk = Math.max(5, baseRisk - reduction);
    const riskReduction = ((baseRisk - newRisk) / baseRisk) * 100;
    
    const baseCost = 4200000;
    const interventionCost = (salaryHike * 50000) + (promotionRate * 30000) + (trainingHours * 5000);
    const savedCost = baseCost * (riskReduction / 100);
    const netSavings = savedCost - interventionCost;
    
    const impacted = Math.round((salaryHike + promotionRate + workloadReduction) * 15);

    return {
      riskReduction,
      costSavings: netSavings,
      employeesImpacted: impacted,
    };
  }, [salaryHike, promotionRate, workloadReduction, trainingHours]);

  return (
    <div className="space-y-6">
      {/* Sliders */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <Label className="text-sm text-foreground">Salary Increase (%)</Label>
            <Badge variant="outline" className="bg-secondary/50">{salaryHike}%</Badge>
          </div>
          <Slider
            value={[salaryHike]}
            onValueChange={([v]) => setSalaryHike(v)}
            max={15}
            step={1}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">
            Higher salaries directly reduce financial-related attrition
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <Label className="text-sm text-foreground">Promotion Rate Increase (%)</Label>
            <Badge variant="outline" className="bg-secondary/50">{promotionRate}%</Badge>
          </div>
          <Slider
            value={[promotionRate]}
            onValueChange={([v]) => setPromotionRate(v)}
            max={10}
            step={1}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">
            Career growth opportunities significantly impact retention
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <Label className="text-sm text-foreground">Workload Reduction (%)</Label>
            <Badge variant="outline" className="bg-secondary/50">{workloadReduction}%</Badge>
          </div>
          <Slider
            value={[workloadReduction]}
            onValueChange={([v]) => setWorkloadReduction(v)}
            max={20}
            step={1}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">
            Reducing overtime and improving work-life balance
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <Label className="text-sm text-foreground">Additional Training Hours</Label>
            <Badge variant="outline" className="bg-secondary/50">{trainingHours}h</Badge>
          </div>
          <Slider
            value={[trainingHours]}
            onValueChange={([v]) => setTrainingHours(v)}
            max={40}
            step={5}
            className="cursor-pointer"
          />
          <p className="text-xs text-muted-foreground">
            Training investment shows commitment to employee growth
          </p>
        </div>
      </div>

      {/* Results */}
      <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/50">
        <div className="text-center p-4 rounded-lg bg-success/10 border border-success/20">
          <TrendingDown className="h-6 w-6 text-success mx-auto mb-2" />
          <p className="text-2xl font-bold text-success">
            {result.riskReduction.toFixed(1)}%
          </p>
          <p className="text-xs text-muted-foreground mt-1">Risk Reduction</p>
        </div>
        
        <div className="text-center p-4 rounded-lg bg-primary/10 border border-primary/20">
          <DollarSign className="h-6 w-6 text-primary mx-auto mb-2" />
          <p className={`text-2xl font-bold ${result.costSavings >= 0 ? 'text-primary' : 'text-risk-high'}`}>
            {result.costSavings >= 0 ? '+' : ''}{formatCurrency(result.costSavings, true)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">Net ROI Savings</p>
        </div>
        
        <div className="text-center p-4 rounded-lg bg-chart-2/10 border border-chart-2/20">
          <Users className="h-6 w-6 text-chart-2 mx-auto mb-2" />
          <p className="text-2xl font-bold text-chart-2">
            {result.employeesImpacted}
          </p>
          <p className="text-xs text-muted-foreground mt-1">Employees Impacted</p>
        </div>
      </div>
    </div>
  );
}
