import { Employee } from '@/lib/employeeData';
import { Badge } from '@/components/ui/badge';
import { 
  TrendingDown, 
  DollarSign, 
  Clock, 
  GraduationCap, 
  Heart, 
  Briefcase,
  Sparkles,
  CheckCircle2,
  ClipboardList,
  Users
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { RiskBadge } from './RiskBadge';

interface RecommendationsPanelProps {
  employee?: Employee;
  compact?: boolean;
}

interface Recommendation {
  id: string;
  title: string;
  description: string;
  impact: 'high' | 'medium' | 'low';
  riskReduction: number;
  icon: React.ReactNode;
  category: string;
}

interface HRAction {
  action: string;
  priority: 'immediate' | 'short-term' | 'ongoing';
  icon: React.ReactNode;
}

function generateRecommendations(employee?: Employee): Recommendation[] {
  if (!employee) return [];

  const recs: Recommendation[] = [];

  if (employee.overTime) {
    recs.push({
      id: 'overtime',
      title: 'Reduce Overtime Hours',
      description: 'Employee regularly works overtime. Consider workload redistribution.',
      impact: 'high',
      riskReduction: 15,
      icon: <Clock className="h-4 w-4" />,
      category: 'Work-Life Balance',
    });
  }

  if (employee.monthlyIncome < (employee.jobLevel * 4000)) {
    recs.push({
      id: 'salary',
      title: 'Salary Adjustment',
      description: `Current salary below market rate for Job Level ${employee.jobLevel}.`,
      impact: 'high',
      riskReduction: 12,
      icon: <DollarSign className="h-4 w-4" />,
      category: 'Compensation',
    });
  }

  if (employee.yearsSinceLastPromotion > 3) {
    recs.push({
      id: 'promotion',
      title: 'Career Advancement',
      description: `${employee.yearsSinceLastPromotion} years since last promotion.`,
      impact: 'high',
      riskReduction: 18,
      icon: <Briefcase className="h-4 w-4" />,
      category: 'Career Development',
    });
  }

  if (employee.jobSatisfaction <= 2) {
    recs.push({
      id: 'satisfaction',
      title: 'Job Satisfaction Review',
      description: 'Low satisfaction scores detected. Schedule a 1:1.',
      impact: 'medium',
      riskReduction: 10,
      icon: <Heart className="h-4 w-4" />,
      category: 'Engagement',
    });
  }

  if (employee.trainingTimesLastYear < 2) {
    recs.push({
      id: 'training',
      title: 'Training & Development',
      description: 'Limited training participation. Offer skill programs.',
      impact: 'medium',
      riskReduction: 8,
      icon: <GraduationCap className="h-4 w-4" />,
      category: 'Development',
    });
  }

  recs.push({
    id: 'checkin',
    title: 'Regular Check-ins',
    description: 'Schedule monthly manager check-ins to maintain engagement.',
    impact: 'low',
    riskReduction: 5,
    icon: <Sparkles className="h-4 w-4" />,
    category: 'Engagement',
  });

  return recs.slice(0, 4);
}

function generateHRActions(employee?: Employee): HRAction[] {
  if (!employee) return [];

  const actions: HRAction[] = [];

  if (employee.riskLevel === 'Critical' || employee.riskLevel === 'High') {
    actions.push({
      action: 'Schedule immediate retention conversation',
      priority: 'immediate',
      icon: <Users className="h-3 w-3" />,
    });
  }

  if (employee.overTime) {
    actions.push({
      action: 'Review workload distribution',
      priority: 'immediate',
      icon: <Clock className="h-3 w-3" />,
    });
  }

  if (employee.yearsSinceLastPromotion > 3) {
    actions.push({
      action: 'Consider promotion discussion',
      priority: 'short-term',
      icon: <Briefcase className="h-3 w-3" />,
    });
  }

  if (employee.monthlyIncome < (employee.jobLevel * 4000)) {
    actions.push({
      action: 'Salary benchmarking suggested',
      priority: 'short-term',
      icon: <DollarSign className="h-3 w-3" />,
    });
  }

  if (employee.jobSatisfaction <= 2) {
    actions.push({
      action: 'Conduct engagement survey follow-up',
      priority: 'short-term',
      icon: <ClipboardList className="h-3 w-3" />,
    });
  }

  if (employee.trainingTimesLastYear < 2) {
    actions.push({
      action: 'Enroll in development program',
      priority: 'ongoing',
      icon: <GraduationCap className="h-3 w-3" />,
    });
  }

  return actions.slice(0, 5);
}

export function RecommendationsPanel({ employee, compact = false }: RecommendationsPanelProps) {
  const recommendations = generateRecommendations(employee);
  const hrActions = generateHRActions(employee);

  if (!employee) {
    return (
      <div className="flex flex-col items-center justify-center h-[300px] text-center">
        <Sparkles className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-base font-medium text-foreground mb-2">Select an Employee</h3>
        <p className="text-xs text-muted-foreground max-w-xs">
          Click on an employee in the table to see personalized retention recommendations
        </p>
      </div>
    );
  }

  const totalReduction = recommendations.reduce((sum, r) => sum + r.riskReduction, 0);

  return (
    <div className="space-y-4">
      {/* Employee header */}
      <div className="flex items-center justify-between pb-3 border-b border-border/50">
        <div>
          <p className="text-xs text-muted-foreground">Recommendations for</p>
          <h3 className="text-base font-medium text-foreground">
            Employee #{employee.id.toString().padStart(4, '0')}
          </h3>
          <p className="text-xs text-muted-foreground">
            {employee.jobRole} • {employee.department}
          </p>
        </div>
        <div className="text-right">
          <RiskBadge level={employee.riskLevel} size="md" />
          <p className="text-lg font-bold text-foreground mt-1">{employee.riskScore}%</p>
        </div>
      </div>

      {/* What Should HR Do? Section */}
      <div className="p-3 rounded-lg bg-primary/5 border border-primary/20">
        <div className="flex items-center gap-2 mb-2">
          <ClipboardList className="h-4 w-4 text-primary" />
          <h4 className="text-sm font-medium text-foreground">What Should HR Do?</h4>
        </div>
        <ul className="space-y-1.5">
          {hrActions.map((item, index) => (
            <li key={index} className="flex items-center gap-2 text-xs">
              <div className={cn(
                'p-1 rounded',
                item.priority === 'immediate' && 'bg-risk-high/20 text-risk-high',
                item.priority === 'short-term' && 'bg-warning/20 text-warning',
                item.priority === 'ongoing' && 'bg-success/20 text-success'
              )}>
                {item.icon}
              </div>
              <span className="text-muted-foreground flex-1">{item.action}</span>
              <Badge variant="outline" className={cn(
                'text-[9px] px-1',
                item.priority === 'immediate' && 'bg-risk-high/10 text-risk-high border-risk-high/30',
                item.priority === 'short-term' && 'bg-warning/10 text-warning border-warning/30',
                item.priority === 'ongoing' && 'bg-success/10 text-success border-success/30'
              )}>
                {item.priority}
              </Badge>
            </li>
          ))}
        </ul>
      </div>

      {/* Detailed Recommendations */}
      {!compact && (
        <div className="space-y-2">
          <h4 className="text-xs font-medium text-muted-foreground uppercase tracking-wide">
            Detailed Recommendations
          </h4>
          {recommendations.map((rec) => (
            <div
              key={rec.id}
              className="p-3 rounded-lg bg-secondary/30 border border-border/50 hover:border-primary/30 transition-all cursor-pointer group"
            >
              <div className="flex items-start gap-2">
                <div className={cn(
                  'p-1.5 rounded-lg shrink-0',
                  rec.impact === 'high' && 'bg-risk-high/20 text-risk-high',
                  rec.impact === 'medium' && 'bg-warning/20 text-warning',
                  rec.impact === 'low' && 'bg-primary/20 text-primary'
                )}>
                  {rec.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1.5 mb-0.5">
                    <h4 className="text-xs font-medium text-foreground">{rec.title}</h4>
                    <Badge variant="outline" className="text-[9px] px-1">
                      {rec.category}
                    </Badge>
                  </div>
                  <p className="text-[11px] text-muted-foreground">{rec.description}</p>
                </div>
                <div className="text-right shrink-0">
                  <div className="flex items-center gap-1">
                    <TrendingDown className="h-3 w-3 text-success" />
                    <span className="text-xs font-medium text-success">-{rec.riskReduction}%</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Total impact */}
      <div className="p-3 rounded-lg bg-success/10 border border-success/20">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-success" />
            <div>
              <p className="text-xs font-medium text-foreground">Potential Risk Reduction</p>
              <p className="text-[10px] text-muted-foreground">If all actions implemented</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xl font-bold text-success">-{Math.min(totalReduction, employee.riskScore)}%</p>
            <p className="text-[10px] text-muted-foreground">
              New risk: {Math.max(0, employee.riskScore - totalReduction)}%
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
