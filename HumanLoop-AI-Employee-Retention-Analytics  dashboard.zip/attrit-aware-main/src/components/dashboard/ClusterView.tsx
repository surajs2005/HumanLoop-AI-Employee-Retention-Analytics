import { generateClusterData } from '@/lib/employeeData';
import { Badge } from '@/components/ui/badge';
import { Users, TrendingUp, DollarSign, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

export function ClusterView() {
  const clusters = generateClusterData();

  const getAttritionColor = (rate: number) => {
    if (rate >= 25) return 'text-risk-high';
    if (rate >= 15) return 'text-warning';
    return 'text-success';
  };

  const getAttritionBg = (rate: number) => {
    if (rate >= 25) return 'bg-risk-high/10 border-risk-high/20';
    if (rate >= 15) return 'bg-warning/10 border-warning/20';
    return 'bg-success/10 border-success/20';
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {clusters.map((cluster) => (
        <div
          key={cluster.cluster}
          className={cn(
            'p-4 rounded-lg border transition-all hover:shadow-elevated',
            getAttritionBg(cluster.attritionRate)
          )}
        >
          <div className="flex items-start justify-between mb-3">
            <h4 className="font-medium text-foreground">{cluster.cluster}</h4>
            <Badge
              variant="outline"
              className={cn('text-xs', getAttritionColor(cluster.attritionRate))}
            >
              {cluster.attritionRate.toFixed(1)}% attrition
            </Badge>
          </div>
          
          <p className="text-xs text-muted-foreground mb-4">{cluster.description}</p>
          
          <div className="grid grid-cols-3 gap-2">
            <div className="text-center">
              <Users className="h-4 w-4 text-muted-foreground mx-auto mb-1" />
              <p className="text-sm font-medium text-foreground">{cluster.count}</p>
              <p className="text-[10px] text-muted-foreground">Employees</p>
            </div>
            <div className="text-center">
              <Clock className="h-4 w-4 text-muted-foreground mx-auto mb-1" />
              <p className="text-sm font-medium text-foreground">{cluster.avgTenure}y</p>
              <p className="text-[10px] text-muted-foreground">Avg Tenure</p>
            </div>
            <div className="text-center">
              <DollarSign className="h-4 w-4 text-muted-foreground mx-auto mb-1" />
              <p className="text-sm font-medium text-foreground">${(cluster.avgIncome / 1000).toFixed(1)}K</p>
              <p className="text-[10px] text-muted-foreground">Avg Income</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}