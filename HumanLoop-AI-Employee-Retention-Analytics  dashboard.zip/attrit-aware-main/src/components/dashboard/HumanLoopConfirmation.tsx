import { useState } from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { UserCheck, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HumanLoopConfirmationProps {
  onConfirm?: (confirmed: boolean) => void;
  className?: string;
}

export function HumanLoopConfirmation({ onConfirm, className }: HumanLoopConfirmationProps) {
  const [confirmed, setConfirmed] = useState(false);

  const handleChange = (checked: boolean) => {
    setConfirmed(checked);
    onConfirm?.(checked);
  };

  return (
    <div
      className={cn(
        'p-4 rounded-lg border transition-all',
        confirmed
          ? 'bg-success/10 border-success/30'
          : 'bg-warning/5 border-warning/30',
        className
      )}
    >
      <div className="flex items-start gap-3">
        <div className={cn(
          'p-2 rounded-lg shrink-0',
          confirmed ? 'bg-success/20' : 'bg-warning/20'
        )}>
          {confirmed ? (
            <UserCheck className="h-4 w-4 text-success" />
          ) : (
            <AlertCircle className="h-4 w-4 text-warning" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-sm font-medium text-foreground">Human-in-the-Loop Review</span>
            <Badge
              variant="outline"
              className={cn(
                'text-[10px]',
                confirmed
                  ? 'bg-success/20 text-success border-success/30'
                  : 'bg-warning/20 text-warning border-warning/30'
              )}
            >
              {confirmed ? 'Confirmed' : 'Pending'}
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            AI predictions are advisory only. All retention actions require HR manager approval.
          </p>
          <div className="flex items-center gap-2">
            <Checkbox
              id="hr-review"
              checked={confirmed}
              onCheckedChange={handleChange}
              className="border-border data-[state=checked]:bg-success data-[state=checked]:border-success"
            />
            <label
              htmlFor="hr-review"
              className="text-xs font-medium text-foreground cursor-pointer select-none"
            >
              HR review required before taking action
            </label>
          </div>
        </div>
      </div>
    </div>
  );
}
