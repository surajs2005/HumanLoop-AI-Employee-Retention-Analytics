import { useState, useMemo } from 'react';
import { Employee } from '@/lib/employeeData';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ChevronUp, ChevronDown, Search, User } from 'lucide-react';
import { cn } from '@/lib/utils';
import { RiskBadge } from './RiskBadge';
import { useCurrency } from '@/contexts/CurrencyContext';

interface EmployeeTableProps {
  employees: Employee[];
  onSelectEmployee?: (employee: Employee) => void;
}

type SortField = 'id' | 'age' | 'department' | 'jobRole' | 'riskScore' | 'monthlyIncome';
type SortOrder = 'asc' | 'desc';

export function EmployeeTable({ employees, onSelectEmployee }: EmployeeTableProps) {
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState<SortField>('riskScore');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;
  const { formatCurrency } = useCurrency();

  const filteredAndSorted = useMemo(() => {
    let result = [...employees];

    // Filter
    if (search) {
      const lowerSearch = search.toLowerCase();
      result = result.filter(
        (e) =>
          e.jobRole.toLowerCase().includes(lowerSearch) ||
          e.department.toLowerCase().includes(lowerSearch) ||
          e.id.toString().includes(lowerSearch)
      );
    }

    // Sort
    result.sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      const modifier = sortOrder === 'asc' ? 1 : -1;
      if (typeof aVal === 'string') {
        return aVal.localeCompare(bVal as string) * modifier;
      }
      return ((aVal as number) - (bVal as number)) * modifier;
    });

    return result;
  }, [employees, search, sortField, sortOrder]);

  const paginatedData = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredAndSorted.slice(start, start + pageSize);
  }, [filteredAndSorted, currentPage]);

  const totalPages = Math.ceil(filteredAndSorted.length / pageSize);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const SortIcon = ({ field }: { field: SortField }) => {
    if (sortField !== field) return null;
    return sortOrder === 'asc' ? (
      <ChevronUp className="h-4 w-4 inline ml-1" />
    ) : (
      <ChevronDown className="h-4 w-4 inline ml-1" />
    );
  };

  const getRiskEmoji = (level: string) => {
    switch (level) {
      case 'Critical':
      case 'High':
        return '🔴';
      case 'Medium':
        return '🟡';
      default:
        return '🟢';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search by role, department..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            className="pl-10 bg-secondary/50 border-border/50"
          />
        </div>
        <span className="text-sm text-muted-foreground">
          {filteredAndSorted.length} employees
        </span>
      </div>

      <div className="rounded-lg border border-border/50 overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-secondary/30 hover:bg-secondary/30">
              <TableHead
                className="cursor-pointer hover:text-primary"
                onClick={() => handleSort('id')}
              >
                ID <SortIcon field="id" />
              </TableHead>
              <TableHead>Employee</TableHead>
              <TableHead
                className="cursor-pointer hover:text-primary"
                onClick={() => handleSort('department')}
              >
                Department <SortIcon field="department" />
              </TableHead>
              <TableHead
                className="cursor-pointer hover:text-primary"
                onClick={() => handleSort('jobRole')}
              >
                Role <SortIcon field="jobRole" />
              </TableHead>
              <TableHead
                className="cursor-pointer hover:text-primary text-right"
                onClick={() => handleSort('monthlyIncome')}
              >
                Income <SortIcon field="monthlyIncome" />
              </TableHead>
              <TableHead
                className="cursor-pointer hover:text-primary text-center"
                onClick={() => handleSort('riskScore')}
              >
                Risk <SortIcon field="riskScore" />
              </TableHead>
              <TableHead className="text-center">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedData.map((emp) => (
              <TableRow
                key={emp.id}
                className="cursor-pointer hover:bg-secondary/20 transition-colors"
                onClick={() => onSelectEmployee?.(emp)}
              >
                <TableCell className="font-mono text-muted-foreground">
                  #{emp.id.toString().padStart(4, '0')}
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                      <User className="h-4 w-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium text-sm">{emp.gender}, {emp.age}y</p>
                      <p className="text-xs text-muted-foreground">{emp.maritalStatus}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-sm">
                  {emp.department === 'Research & Development' ? 'R&D' : emp.department}
                </TableCell>
                <TableCell className="text-sm max-w-[150px] truncate" title={emp.jobRole}>
                  {emp.jobRole}
                </TableCell>
                <TableCell className="text-right font-medium text-sm">
                  {formatCurrency(emp.monthlyIncome)}
                </TableCell>
                <TableCell className="text-center">
                  <div className="flex items-center justify-center gap-2">
                    <div
                      className="w-12 h-2 rounded-full bg-secondary overflow-hidden"
                      title={`Risk Score: ${emp.riskScore}%`}
                    >
                      <div
                        className={cn(
                          'h-full rounded-full transition-all',
                          emp.riskLevel === 'Critical' && 'bg-risk-critical',
                          emp.riskLevel === 'High' && 'bg-risk-high',
                          emp.riskLevel === 'Medium' && 'bg-warning',
                          emp.riskLevel === 'Low' && 'bg-success'
                        )}
                        style={{ width: `${emp.riskScore}%` }}
                      />
                    </div>
                    <span className="text-xs font-medium w-8">{emp.riskScore}%</span>
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <RiskBadge level={emp.riskLevel} size="sm" />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Showing {(currentPage - 1) * pageSize + 1} to{' '}
          {Math.min(currentPage * pageSize, filteredAndSorted.length)} of{' '}
          {filteredAndSorted.length}
        </p>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
          >
            Previous
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
          >
            Next
          </Button>
        </div>
      </div>
    </div>
  );
}