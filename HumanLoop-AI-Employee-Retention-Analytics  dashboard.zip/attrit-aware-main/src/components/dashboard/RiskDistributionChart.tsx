import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

interface RiskDistributionProps {
  data: { level: string; count: number; percentage: number }[];
}

const COLORS = {
  Low: 'hsl(155, 70%, 45%)',
  Medium: 'hsl(38, 92%, 55%)',
  High: 'hsl(0, 75%, 58%)',
  Critical: 'hsl(350, 85%, 50%)',
};

export function RiskDistributionChart({ data }: RiskDistributionProps) {
  return (
    <div className="flex items-center gap-6">
      <div className="w-[180px] h-[180px]">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={50}
              outerRadius={80}
              paddingAngle={3}
              dataKey="count"
            >
              {data.map((entry) => (
                <Cell
                  key={entry.level}
                  fill={COLORS[entry.level as keyof typeof COLORS]}
                  stroke="transparent"
                />
              ))}
            </Pie>
            <Tooltip
              content={({ active, payload }) => {
                if (active && payload && payload.length) {
                  const d = payload[0].payload;
                  return (
                    <div className="bg-popover border border-border rounded-lg p-2 shadow-elevated">
                      <p className="text-sm font-medium">{d.level}: {d.count}</p>
                      <p className="text-xs text-muted-foreground">{d.percentage.toFixed(1)}%</p>
                    </div>
                  );
                }
                return null;
              }}
            />
          </PieChart>
        </ResponsiveContainer>
      </div>

      <div className="space-y-3 flex-1">
        {data.map((item) => (
          <div key={item.level} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: COLORS[item.level as keyof typeof COLORS] }}
              />
              <span className="text-sm text-foreground">{item.level}</span>
            </div>
            <div className="text-right">
              <span className="text-sm font-medium text-foreground">{item.count}</span>
              <span className="text-xs text-muted-foreground ml-2">
                ({item.percentage.toFixed(1)}%)
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}