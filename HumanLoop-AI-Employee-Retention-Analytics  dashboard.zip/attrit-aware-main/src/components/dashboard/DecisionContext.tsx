import { Lightbulb } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DecisionContextProps {
  insight: string;
  variant?: 'default' | 'warning' | 'success';
  className?: string;
}

export function DecisionContext({ insight, variant = 'default', className }: DecisionContextProps) {
  return (
    <div
      className={cn(
        'flex items-start gap-2 p-3 rounded-lg text-xs',
        variant === 'default' && 'bg-info/10 border border-info/20 text-info',
        variant === 'warning' && 'bg-warning/10 border border-warning/20 text-warning',
        variant === 'success' && 'bg-success/10 border border-success/20 text-success',
        className
      )}
    >
      <Lightbulb className="h-3.5 w-3.5 mt-0.5 shrink-0" />
      <p className="leading-relaxed">{insight}</p>
    </div>
  );
}
