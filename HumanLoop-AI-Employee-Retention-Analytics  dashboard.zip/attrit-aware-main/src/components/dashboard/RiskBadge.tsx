import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface RiskBadgeProps {
  level: 'Low' | 'Medium' | 'High' | 'Critical';
  showEmoji?: boolean;
  size?: 'sm' | 'md';
  className?: string;
}

const RISK_CONFIG = {
  Low: {
    emoji: '🟢',
    label: 'Low Risk',
    className: 'bg-success/20 text-success border-success/30',
  },
  Medium: {
    emoji: '🟡',
    label: 'Medium Risk',
    className: 'bg-warning/20 text-warning border-warning/30',
  },
  High: {
    emoji: '🔴',
    label: 'High Risk',
    className: 'bg-risk-high/20 text-risk-high border-risk-high/30',
  },
  Critical: {
    emoji: '🔴',
    label: 'Critical',
    className: 'bg-risk-critical/20 text-risk-critical border-risk-critical/30',
  },
};

export function RiskBadge({ level, showEmoji = true, size = 'md', className }: RiskBadgeProps) {
  const config = RISK_CONFIG[level];

  return (
    <Badge
      variant="outline"
      className={cn(
        config.className,
        size === 'sm' && 'text-[10px] px-1.5 py-0',
        size === 'md' && 'text-xs px-2 py-0.5',
        className
      )}
    >
      {showEmoji && <span className="mr-1">{config.emoji}</span>}
      {config.label}
    </Badge>
  );
}

export function RiskLegend({ className }: { className?: string }) {
  return (
    <div className={cn('flex flex-wrap items-center gap-3', className)}>
      <span className="text-xs text-muted-foreground">Risk Levels:</span>
      <div className="flex items-center gap-1.5">
        <span className="text-sm">🟢</span>
        <span className="text-xs text-muted-foreground">Low (&lt;30%)</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="text-sm">🟡</span>
        <span className="text-xs text-muted-foreground">Medium (30-49%)</span>
      </div>
      <div className="flex items-center gap-1.5">
        <span className="text-sm">🔴</span>
        <span className="text-xs text-muted-foreground">High (50%+)</span>
      </div>
    </div>
  );
}
