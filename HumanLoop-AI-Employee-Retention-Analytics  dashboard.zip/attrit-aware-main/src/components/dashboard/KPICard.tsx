import { ReactNode } from 'react';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface KPICardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  icon?: ReactNode;
  variant?: 'default' | 'primary' | 'success' | 'warning' | 'danger';
  tooltip?: string;
}

export function KPICard({
  title,
  value,
  subtitle,
  trend,
  trendValue,
  icon,
  variant = 'default',
  tooltip,
}: KPICardProps) {
  const variantStyles = {
    default: 'border-border/50',
    primary: 'border-primary/30 bg-primary/5',
    success: 'border-success/30 bg-success/5',
    warning: 'border-warning/30 bg-warning/5',
    danger: 'border-risk-high/30 bg-risk-high/5',
  };

  const iconColors = {
    default: 'text-muted-foreground',
    primary: 'text-primary',
    success: 'text-success',
    warning: 'text-warning',
    danger: 'text-risk-high',
  };

  const TrendIcon = trend === 'up' ? TrendingUp : trend === 'down' ? TrendingDown : Minus;
  const trendColor = trend === 'up' ? 'text-success' : trend === 'down' ? 'text-risk-high' : 'text-muted-foreground';

  return (
    <div
      className={cn(
        'stat-card group cursor-default animate-slide-up',
        variantStyles[variant]
      )}
      title={tooltip}
    >
      <div className="flex items-start justify-between">
        <div className="space-y-1">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-3xl font-bold tracking-tight text-foreground">{value}</p>
          {subtitle && (
            <p className="text-xs text-muted-foreground">{subtitle}</p>
          )}
        </div>
        {icon && (
          <div className={cn('p-2 rounded-lg bg-secondary/50', iconColors[variant])}>
            {icon}
          </div>
        )}
      </div>
      
      {trend && trendValue && (
        <div className={cn('flex items-center gap-1 mt-3 text-sm', trendColor)}>
          <TrendIcon className="h-4 w-4" />
          <span className="font-medium">{trendValue}</span>
          <span className="text-muted-foreground">vs last period</span>
        </div>
      )}
    </div>
  );
}