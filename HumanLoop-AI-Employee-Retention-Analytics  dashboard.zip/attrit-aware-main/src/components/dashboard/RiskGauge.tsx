import { useMemo } from 'react';

interface RiskGaugeProps {
  value: number; // 0-100
  label?: string;
  size?: 'sm' | 'md' | 'lg';
}

export function RiskGauge({ value, label = 'Overall Risk', size = 'md' }: RiskGaugeProps) {
  const dimensions = {
    sm: { width: 140, height: 80, strokeWidth: 10 },
    md: { width: 200, height: 110, strokeWidth: 14 },
    lg: { width: 280, height: 150, strokeWidth: 18 },
  };

  const { width, height, strokeWidth } = dimensions[size];
  const radius = width / 2 - strokeWidth;
  const circumference = Math.PI * radius;

  const { color, riskLabel } = useMemo(() => {
    if (value >= 70) return { color: 'hsl(350, 85%, 50%)', riskLabel: 'Critical' };
    if (value >= 50) return { color: 'hsl(0, 75%, 58%)', riskLabel: 'High' };
    if (value >= 30) return { color: 'hsl(38, 92%, 55%)', riskLabel: 'Medium' };
    return { color: 'hsl(155, 70%, 45%)', riskLabel: 'Low' };
  }, [value]);

  const dashOffset = circumference - (value / 100) * circumference;

  return (
    <div className="flex flex-col items-center">
      <svg width={width} height={height} className="overflow-visible">
        {/* Background arc */}
        <path
          d={`M ${strokeWidth} ${height - 5} A ${radius} ${radius} 0 0 1 ${width - strokeWidth} ${height - 5}`}
          fill="none"
          stroke="hsl(222, 15%, 20%)"
          strokeWidth={strokeWidth}
          strokeLinecap="round"
        />
        
        {/* Gradient definition */}
        <defs>
          <linearGradient id="riskGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="hsl(155, 70%, 45%)" />
            <stop offset="40%" stopColor="hsl(38, 92%, 55%)" />
            <stop offset="70%" stopColor="hsl(0, 75%, 58%)" />
            <stop offset="100%" stopColor="hsl(350, 85%, 50%)" />
          </linearGradient>
        </defs>
        
        {/* Value arc */}
        <path
          d={`M ${strokeWidth} ${height - 5} A ${radius} ${radius} 0 0 1 ${width - strokeWidth} ${height - 5}`}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={dashOffset}
          className="transition-all duration-1000 ease-out"
          style={{ filter: `drop-shadow(0 0 8px ${color})` }}
        />
        
        {/* Center text */}
        <text
          x={width / 2}
          y={height - 25}
          textAnchor="middle"
          className="text-3xl font-bold fill-foreground"
        >
          {value}%
        </text>
      </svg>
      
      <div className="text-center mt-2">
        <p className="text-xs text-muted-foreground uppercase tracking-wider">{label}</p>
        <p 
          className="text-sm font-semibold mt-1"
          style={{ color }}
        >
          {riskLabel} Risk
        </p>
      </div>
    </div>
  );
}