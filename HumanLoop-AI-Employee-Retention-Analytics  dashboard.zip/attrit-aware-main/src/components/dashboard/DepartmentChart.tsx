import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface DepartmentData {
  department: string;
  fullName: string;
  employees: number;
  attritionRate: number;
  avgRiskScore: number;
  attritionCost: number;
}

interface DepartmentChartProps {
  data: DepartmentData[];
  metric?: 'attritionRate' | 'avgRiskScore' | 'attritionCost';
}

export function DepartmentChart({ data, metric = 'attritionRate' }: DepartmentChartProps) {
  const getColor = (value: number) => {
    if (metric === 'attritionRate') {
      if (value >= 20) return 'hsl(0, 75%, 58%)';
      if (value >= 15) return 'hsl(38, 92%, 55%)';
      return 'hsl(185, 65%, 50%)';
    }
    if (metric === 'avgRiskScore') {
      if (value >= 50) return 'hsl(0, 75%, 58%)';
      if (value >= 30) return 'hsl(38, 92%, 55%)';
      return 'hsl(185, 65%, 50%)';
    }
    // attritionCost - always use chart color
    return 'hsl(185, 65%, 50%)';
  };

  const formatValue = (value: number) => {
    if (metric === 'attritionCost') return `$${(value / 1000).toFixed(0)}K`;
    return `${value.toFixed(1)}%`;
  };

  const metricLabels = {
    attritionRate: 'Attrition Rate',
    avgRiskScore: 'Avg Risk Score',
    attritionCost: 'Attrition Cost',
  };

  return (
    <div className="h-[250px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <XAxis
            dataKey="department"
            tick={{ fill: 'hsl(210, 20%, 90%)', fontSize: 12 }}
            axisLine={{ stroke: 'hsl(222, 15%, 20%)' }}
          />
          <YAxis
            tick={{ fill: 'hsl(215, 15%, 55%)', fontSize: 12 }}
            axisLine={{ stroke: 'hsl(222, 15%, 20%)' }}
            tickFormatter={(v) => (metric === 'attritionCost' ? `$${v / 1000}K` : `${v}%`)}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const d = payload[0].payload as DepartmentData;
                return (
                  <div className="bg-popover border border-border rounded-lg p-3 shadow-elevated">
                    <p className="font-medium text-foreground">{d.fullName}</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Employees: <span className="text-foreground">{d.employees}</span>
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {metricLabels[metric]}: <span className="text-primary font-medium">{formatValue(d[metric])}</span>
                    </p>
                  </div>
                );
              }
              return null;
            }}
          />
          <Bar dataKey={metric} radius={[4, 4, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getColor(entry[metric])} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}