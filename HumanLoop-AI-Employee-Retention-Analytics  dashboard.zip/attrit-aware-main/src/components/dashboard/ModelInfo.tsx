import { Badge } from '@/components/ui/badge';
import { Cpu, Clock, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ModelInfoProps {
  version?: string;
  lastRun?: Date;
  className?: string;
}

export function ModelInfo({ 
  version = 'v1.0', 
  lastRun = new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
  className 
}: ModelInfoProps) {
  const formatTimestamp = (date: Date) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMins = Math.floor(diffMs / (1000 * 60));

    if (diffMins < 60) {
      return `${diffMins} min ago`;
    } else if (diffHours < 24) {
      return `${diffHours}h ago`;
    } else {
      return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    }
  };

  return (
    <div className={cn('flex items-center gap-4 text-xs', className)}>
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Cpu className="h-3.5 w-3.5" />
        <span>Model Version:</span>
        <Badge variant="outline" className="text-[10px] px-1.5 bg-primary/10 text-primary border-primary/30">
          {version}
        </Badge>
      </div>
      <div className="flex items-center gap-1.5 text-muted-foreground">
        <Clock className="h-3.5 w-3.5" />
        <span>Last Run:</span>
        <span className="text-foreground font-medium">{formatTimestamp(lastRun)}</span>
      </div>
      <div className="flex items-center gap-1 text-success">
        <RefreshCw className="h-3 w-3" />
        <span className="font-medium">Synced</span>
      </div>
    </div>
  );
}
