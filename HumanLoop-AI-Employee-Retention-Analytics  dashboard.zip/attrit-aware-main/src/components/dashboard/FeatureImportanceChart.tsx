import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { generateFeatureImportance } from '@/lib/employeeData';

export function FeatureImportanceChart() {
  const data = generateFeatureImportance();

  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          layout="vertical"
          margin={{ top: 10, right: 30, left: 100, bottom: 10 }}
        >
          <XAxis
            type="number"
            domain={[0, 0.3]}
            tickFormatter={(v) => `${(v * 100).toFixed(0)}%`}
            tick={{ fill: 'hsl(215, 15%, 55%)', fontSize: 12 }}
            axisLine={{ stroke: 'hsl(222, 15%, 20%)' }}
          />
          <YAxis
            type="category"
            dataKey="feature"
            tick={{ fill: 'hsl(210, 20%, 90%)', fontSize: 12 }}
            axisLine={{ stroke: 'hsl(222, 15%, 20%)' }}
            width={95}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const data = payload[0].payload;
                return (
                  <div className="bg-popover border border-border rounded-lg p-3 shadow-elevated">
                    <p className="font-medium text-foreground">{data.feature}</p>
                    <p className="text-sm text-muted-foreground mt-1">
                      Importance: <span className="text-primary font-medium">{(data.importance * 100).toFixed(1)}%</span>
                    </p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {data.direction === 'negative' 
                        ? '↑ Higher values increase attrition risk' 
                        : '↓ Higher values decrease attrition risk'}
                    </p>
                  </div>
                );
              }
              return null;
            }}
          />
          <Bar dataKey="importance" radius={[0, 4, 4, 0]}>
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={entry.direction === 'negative' ? 'hsl(0, 75%, 58%)' : 'hsl(185, 65%, 50%)'}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      
      <div className="flex justify-center gap-6 mt-4">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-primary" />
          <span className="text-xs text-muted-foreground">Reduces Risk</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 rounded bg-risk-high" />
          <span className="text-xs text-muted-foreground">Increases Risk</span>
        </div>
      </div>
    </div>
  );
}