import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { generateSurvivalData } from '@/lib/employeeData';

export function SurvivalChart() {
  const data = generateSurvivalData();

  return (
    <div className="h-[250px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="survivalGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="hsl(185, 65%, 50%)" stopOpacity={0.3} />
              <stop offset="95%" stopColor="hsl(185, 65%, 50%)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis
            dataKey="month"
            tick={{ fill: 'hsl(215, 15%, 55%)', fontSize: 12 }}
            axisLine={{ stroke: 'hsl(222, 15%, 20%)' }}
            tickFormatter={(v) => `${v}mo`}
          />
          <YAxis
            domain={[60, 100]}
            tick={{ fill: 'hsl(215, 15%, 55%)', fontSize: 12 }}
            axisLine={{ stroke: 'hsl(222, 15%, 20%)' }}
            tickFormatter={(v) => `${v}%`}
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                const d = payload[0].payload;
                return (
                  <div className="bg-popover border border-border rounded-lg p-3 shadow-elevated">
                    <p className="text-sm text-muted-foreground">Month {d.month}</p>
                    <p className="text-lg font-medium text-primary">{d.survival}% Retention</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      {100 - d.survival}% cumulative attrition
                    </p>
                  </div>
                );
              }
              return null;
            }}
          />
          <ReferenceLine y={80} stroke="hsl(38, 92%, 55%)" strokeDasharray="5 5" />
          <Area
            type="monotone"
            dataKey="survival"
            stroke="hsl(185, 65%, 50%)"
            strokeWidth={2}
            fill="url(#survivalGradient)"
          />
        </AreaChart>
      </ResponsiveContainer>
      
      <p className="text-xs text-muted-foreground text-center mt-2">
        Kaplan-Meier style survival curve showing employee retention over time
      </p>
    </div>
  );
}