import { generateBiasData } from '@/lib/employeeData';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, AlertTriangle, ShieldCheck } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';

export function BiasAnalysis() {
  const biasData = generateBiasData();

  const genderDiff = Math.abs(biasData.gender[0].predictedRisk - biasData.gender[1].predictedRisk);
  const isGenderFair = genderDiff < 5;

  return (
    <div className="space-y-6">
      {/* Fairness indicators */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-lg bg-success/10 border border-success/20">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="h-5 w-5 text-success" />
            <span className="font-medium text-foreground">Gender Parity</span>
          </div>
          <p className="text-xs text-muted-foreground">
            Risk predictions are within {genderDiff.toFixed(1)}% across genders
          </p>
          <Badge className="mt-2 bg-success/20 text-success border-success/30">
            {isGenderFair ? 'Fair' : 'Review Needed'}
          </Badge>
        </div>

        <div className="p-4 rounded-lg bg-warning/10 border border-warning/20">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            <span className="font-medium text-foreground">Job Level Variance</span>
          </div>
          <p className="text-xs text-muted-foreground">
            Entry-level employees show higher risk predictions
          </p>
          <Badge className="mt-2 bg-warning/20 text-warning border-warning/30">
            Monitor
          </Badge>
        </div>

        <div className="p-4 rounded-lg bg-primary/10 border border-primary/20">
          <div className="flex items-center gap-2 mb-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            <span className="font-medium text-foreground">Human Oversight</span>
          </div>
          <p className="text-xs text-muted-foreground">
            All high-risk predictions reviewed by HR managers
          </p>
          <Badge className="mt-2 bg-primary/20 text-primary border-primary/30">
            Active
          </Badge>
        </div>
      </div>

      {/* Gender comparison chart */}
      <div>
        <h4 className="text-sm font-medium text-foreground mb-4">Predicted vs Actual Attrition by Gender</h4>
        <div className="h-[180px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={biasData.gender} layout="vertical" margin={{ left: 60 }}>
              <XAxis
                type="number"
                tick={{ fill: 'hsl(215, 15%, 55%)', fontSize: 12 }}
                axisLine={{ stroke: 'hsl(222, 15%, 20%)' }}
                tickFormatter={(v) => `${v}%`}
              />
              <YAxis
                type="category"
                dataKey="group"
                tick={{ fill: 'hsl(210, 20%, 90%)', fontSize: 12 }}
                axisLine={{ stroke: 'hsl(222, 15%, 20%)' }}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const d = payload[0].payload;
                    return (
                      <div className="bg-popover border border-border rounded-lg p-3 shadow-elevated">
                        <p className="font-medium text-foreground">{d.group}</p>
                        <p className="text-sm text-muted-foreground">Sample: {d.count}</p>
                        <p className="text-sm">
                          Predicted: <span className="text-chart-2">{d.predictedRisk}%</span>
                        </p>
                        <p className="text-sm">
                          Actual: <span className="text-primary">{d.actualAttrition}%</span>
                        </p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Legend />
              <Bar dataKey="predictedRisk" name="Predicted Risk" fill="hsl(200, 75%, 55%)" radius={[0, 4, 4, 0]} />
              <Bar dataKey="actualAttrition" name="Actual Attrition" fill="hsl(185, 65%, 50%)" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Governance note */}
      <div className="p-4 rounded-lg bg-secondary/30 border border-border/50">
        <h4 className="text-sm font-medium text-foreground mb-2">AI Governance Policy</h4>
        <ul className="text-xs text-muted-foreground space-y-1">
          <li>• Model predictions are recommendations only—final decisions made by HR</li>
          <li>• Protected attributes (age, gender) excluded from direct model input</li>
          <li>• Quarterly bias audits conducted by Data Ethics committee</li>
          <li>• Employee right to explanation available upon request</li>
        </ul>
      </div>
    </div>
  );
}