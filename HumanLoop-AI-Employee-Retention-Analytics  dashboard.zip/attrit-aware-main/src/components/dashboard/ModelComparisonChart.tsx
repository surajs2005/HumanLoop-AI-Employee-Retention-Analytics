import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend, ResponsiveContainer } from 'recharts';
import { generateModelComparison } from '@/lib/employeeData';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export function ModelComparisonChart() {
  const models = generateModelComparison();
  
  const radarData = [
    { metric: 'AUC', ...Object.fromEntries(models.map(m => [m.model.split(' ')[0], m.auc * 100])) },
    { metric: 'Recall', ...Object.fromEntries(models.map(m => [m.model.split(' ')[0], m.recall * 100])) },
    { metric: 'Stability', ...Object.fromEntries(models.map(m => [m.model.split(' ')[0], m.stability * 100])) },
  ];

  return (
    <div className="space-y-6">
      {/* Model cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {models.map((model, idx) => (
          <div
            key={model.model}
            className={cn(
              'p-3 rounded-lg border transition-all hover:border-primary/50',
              model.model === 'Ensemble' ? 'bg-primary/10 border-primary/30' : 'bg-secondary/30 border-border/50'
            )}
          >
            <div className="flex items-center gap-2 mb-2">
              <Badge
                variant="outline"
                className={cn(
                  'text-[10px] px-1.5',
                  model.type === 'DL' && 'bg-chart-6/20 text-chart-6 border-chart-6/30',
                  model.type === 'ML' && 'bg-chart-2/20 text-chart-2 border-chart-2/30',
                  model.type === 'Ensemble' && 'bg-primary/20 text-primary border-primary/30'
                )}
              >
                {model.type}
              </Badge>
            </div>
            <p className="text-sm font-medium text-foreground truncate" title={model.model}>
              {model.model.split(' ')[0]}
            </p>
            <div className="mt-2 space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">AUC</span>
                <span className="text-foreground font-medium">{(model.auc * 100).toFixed(0)}%</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Recall</span>
                <span className="text-foreground font-medium">{(model.recall * 100).toFixed(0)}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Info box */}
      <div className="bg-secondary/30 border border-border/50 rounded-lg p-4">
        <h4 className="text-sm font-medium text-foreground mb-2">ML vs DL Explained</h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-muted-foreground">
          <div>
            <span className="text-chart-2 font-medium">Machine Learning (ML)</span>
            <p className="mt-1">Traditional algorithms like Random Forest and XGBoost. Highly interpretable, fast training, works well with structured data.</p>
          </div>
          <div>
            <span className="text-chart-6 font-medium">Deep Learning (DL)</span>
            <p className="mt-1">Neural networks that can capture complex patterns. Better at finding hidden interactions but requires more data and compute.</p>
          </div>
        </div>
      </div>
    </div>
  );
}