import { useCurrency, CurrencyCode, CURRENCIES } from '@/contexts/CurrencyContext';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import { ChevronDown, Globe } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ScrollArea } from '@/components/ui/scroll-area';

const CURRENCY_ORDER: CurrencyCode[] = ['USD', 'EUR', 'GBP', 'INR', 'JPY', 'AUD', 'CAD', 'SGD', 'CHF', 'AED'];

export function CurrencySelector({ className }: { className?: string }) {
  const { currency, setCurrency, config } = useCurrency();

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="outline"
          size="sm"
          className={cn(
            'h-8 gap-1.5 bg-secondary/50 border-border/50 text-xs font-medium',
            className
          )}
        >
          <Globe className="h-3.5 w-3.5 text-muted-foreground" />
          <span className="text-primary font-semibold">{config.symbol}</span>
          <span>{currency}</span>
          <ChevronDown className="h-3 w-3 text-muted-foreground" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-52 bg-popover">
        <DropdownMenuLabel className="text-xs text-muted-foreground font-normal">
          Select Display Currency
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <ScrollArea className="h-[280px]">
          {CURRENCY_ORDER.map((code) => {
            const curr = CURRENCIES[code];
            return (
              <DropdownMenuItem
                key={code}
                onClick={() => setCurrency(code)}
                className={cn(
                  'flex items-center gap-2 cursor-pointer',
                  currency === code && 'bg-primary/10 text-primary'
                )}
              >
                <span className="w-6 font-semibold text-right">{curr.symbol}</span>
                <span className="flex-1">{curr.name}</span>
                <span className="text-[10px] text-muted-foreground">{code}</span>
                {currency === code && (
                  <span className="text-primary">✓</span>
                )}
              </DropdownMenuItem>
            );
          })}
        </ScrollArea>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
