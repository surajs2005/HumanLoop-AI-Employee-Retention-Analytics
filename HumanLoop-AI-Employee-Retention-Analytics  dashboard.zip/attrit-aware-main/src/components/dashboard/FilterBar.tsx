import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { X, Filter } from 'lucide-react';

interface FilterBarProps {
  departments: string[];
  roles: string[];
  selectedDepartment: string;
  selectedRole: string;
  selectedGender: string;
  selectedRisk: string;
  onDepartmentChange: (value: string) => void;
  onRoleChange: (value: string) => void;
  onGenderChange: (value: string) => void;
  onRiskChange: (value: string) => void;
  onClearFilters: () => void;
}

export function FilterBar({
  departments,
  roles,
  selectedDepartment,
  selectedRole,
  selectedGender,
  selectedRisk,
  onDepartmentChange,
  onRoleChange,
  onGenderChange,
  onRiskChange,
  onClearFilters,
}: FilterBarProps) {
  const hasFilters = selectedDepartment || selectedRole || selectedGender || selectedRisk;

  return (
    <div className="flex flex-wrap items-center gap-3 p-4 rounded-lg bg-secondary/30 border border-border/50">
      <Filter className="h-4 w-4 text-muted-foreground" />
      <span className="text-sm font-medium text-muted-foreground mr-2">Filters:</span>

      <Select value={selectedDepartment} onValueChange={onDepartmentChange}>
        <SelectTrigger className="w-[160px] h-9 bg-secondary/50 border-border/50">
          <SelectValue placeholder="All Departments" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Departments</SelectItem>
          {departments.map((dept) => (
            <SelectItem key={dept} value={dept}>
              {dept === 'Research & Development' ? 'R&D' : dept}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={selectedRole} onValueChange={onRoleChange}>
        <SelectTrigger className="w-[180px] h-9 bg-secondary/50 border-border/50">
          <SelectValue placeholder="All Roles" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Roles</SelectItem>
          {roles.map((role) => (
            <SelectItem key={role} value={role}>
              {role}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      <Select value={selectedGender} onValueChange={onGenderChange}>
        <SelectTrigger className="w-[120px] h-9 bg-secondary/50 border-border/50">
          <SelectValue placeholder="All Genders" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Genders</SelectItem>
          <SelectItem value="Male">Male</SelectItem>
          <SelectItem value="Female">Female</SelectItem>
        </SelectContent>
      </Select>

      <Select value={selectedRisk} onValueChange={onRiskChange}>
        <SelectTrigger className="w-[140px] h-9 bg-secondary/50 border-border/50">
          <SelectValue placeholder="All Risk Levels" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Risk Levels</SelectItem>
          <SelectItem value="Critical">Critical</SelectItem>
          <SelectItem value="High">High</SelectItem>
          <SelectItem value="Medium">Medium</SelectItem>
          <SelectItem value="Low">Low</SelectItem>
        </SelectContent>
      </Select>

      {hasFilters && (
        <Button
          variant="ghost"
          size="sm"
          onClick={onClearFilters}
          className="h-9 text-muted-foreground hover:text-foreground"
        >
          <X className="h-4 w-4 mr-1" />
          Clear
        </Button>
      )}
    </div>
  );
}